# 📊 Swiggy Company Analysis — Analyst Dashboard

> **Prepared by:** Avishkar Patil  
> **Programme:** Master of Management Studies (MMS) — Finance  
> **Date:** June 6, 2026  

An interactive, single-page analyst dashboard for Swiggy Limited — covering business model, KPIs, competitive landscape, risks, and growth opportunities.

---

## 🚀 Live Preview

Host on GitHub Pages (see below) or open `index.html` directly in any modern browser.

---

## 📁 Project Structure

```
swiggy-dashboard/
├── index.html       # Main dashboard (all HTML structure)
├── style.css        # Dark-professional styling + responsive layout
├── app.js           # Chart.js charts + tab/segment interactivity
└── README.md        # This file
```

---

## 📦 Dependencies

All loaded via CDN — **no npm/build step required**:

| Library | Version | Purpose |
|---------|---------|---------|
| Chart.js | 4.4.1 | All charts (bar, line, doughnut, radar) |
| Google Fonts (Inter + DM Mono) | latest | Typography |

---

## 🖥️ Features

| Section | Content |
|---------|---------|
| **Overview** | Company summary, hero stats, timeline, revenue mix pie chart |
| **Business Segments** | Sub-tabbed: Food Delivery, Instamart, Dineout, Bolt — each with KPI charts |
| **KPI Tracker** | MTU, GOV, Instamart AOV, Dark Stores, Contribution Margin — all quarterly |
| **Competitive Landscape** | Market share charts, comparison matrix, Bull/Bear cases |
| **Risks & Opportunities** | Risk radar, growth opportunity bar chart, deep-dive cards |
| **Analyst Verdict** | SWOT grid, score gauge, path-to-profitability chart, key questions to watch |

---

## 🌐 Hosting on GitHub Pages

1. Push this folder to a GitHub repository:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Swiggy Analyst Dashboard"
   git remote add origin https://github.com/YOUR_USERNAME/swiggy-dashboard.git
   git push -u origin main
   ```

2. Go to **Settings → Pages** in your GitHub repo

3. Under **Source**, select `main` branch and `/ (root)` folder

4. Click **Save** — your site will be live at:
   ```
   https://YOUR_USERNAME.github.io/swiggy-dashboard/
   ```

---

## 📊 Data Sources

- Swiggy FY25 Annual Report
- Swiggy Q2FY26 Earnings Results
- AllianceBernstein India E-Commerce Research Report
- Economic Times (Quick Commerce market share)
- KPMG India Quick Commerce Industry Report 2024

> ⚠️ This dashboard is for **educational purposes only** and does not constitute investment advice.

---

## 📐 Design

- **Palette:** Dark background (`#0d0f14`) + Swiggy Orange (`#fc6011`) accent
- **Typography:** Inter (UI) + DM Mono (data/numbers)
- **Charts:** Chart.js 4.4.1 — bar, line, doughnut, radar
- **Interactions:** Smooth tab transitions, hover effects, animated chart entry
- **Responsive:** Works on desktop, tablet, and mobile

---

*© 2026 Avishkar Patil — MMS Finance Research*
